const md5 = require('md5')

console.log(md5('message'));
