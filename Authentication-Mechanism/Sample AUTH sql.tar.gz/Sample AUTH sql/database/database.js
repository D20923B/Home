const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database(':memory:');

db.serialize(() => {
    db.run("CREATE TABLE UserDatabase (username TEXT,password TEXT,address TEXT, email TEXT, Phone_number NUMBER ,email_otp NUMBER,email_veryfied TEXT,admin TEXT)");
});

module.exports=db;
