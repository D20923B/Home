const express = require('express');
const router=express.Router();
const methods = require('./../scripts/sign_up_methods.js')
const jwt = require('jsonwebtoken');
const path = require('path');





router.get('/',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../html_templates')
    };

    var fileName = 'sign_up.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})







router.post('/sign_up_data',async function(req,res){

  console.log(req.body);

  if(await methods.check_email(req.body.email)==false)
  {

    var otp=Math.floor(100000+Math.random()*9000000)
    methods.store_data(req.body.username,req.body.password,req.body.address,req.body.email,req.body.phone_number,otp);

    let jwtSecretKey = process.env.JWT_SECRET_KEY;

    let data = {
        email:req.body.email,
        password:req.body.password
    }

    const token = jwt.sign(data, jwtSecretKey);
    res.cookie("UserSession", token);
    res.redirect('/signup/verify_email');

  }
  else if (await methods.check_email(req.body.email)==true)
  {

    res.send('Email already exists')

  }

})








router.get('/verify_email',async (req,res)=>{

  if(req.cookies.UserSession!=undefined)
  {

    var options = {
          root: path.join(__dirname,'./../html_templates')
      };

      var fileName = 'Otp_verification.html';
      res.sendFile(fileName, options, function (err) {
          if (err) {
              next(err);
          }
      });

  }
  else
  {

      res.redirect('/');

  }
})








router.post('/verify_email_data',async (req,res)=>{

  if(jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY)!=undefined)
  {

    if(await methods.verify_email(jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY).email,parseInt(req.body.otp))==true)
    {

        res.send('WELCOME to E-market')

    }
    else
    {

      res.send('opt invalid Please visit the previous page and try again')

    }

  }
  else
  {

    res.send('Session not valid')

  }
})








router.get('/email',(req,res)=>{

  res.send('sign up using email');

})




module.exports=router;
