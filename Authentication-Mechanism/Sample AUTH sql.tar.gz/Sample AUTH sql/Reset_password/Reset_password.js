const express = require('express');
const router=express.Router();
const path = require('path');
const jwt = require('jsonwebtoken')
const nodemailer = require('nodemailer');
const send_opt_to_mail =require('./../scripts/sending_otp_mail.js')
const Password_reset =require('./../scripts/password_reset.js')


router.get('/Reset_password',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../html_templates')
    };

    var fileName = 'ResetPassword.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})

router.post('/Reset_password/email',async(req,res)=>{

  if(await Password_reset.check_email(req.body.email)==true)
  {

    var otp=Math.floor(100000+Math.random()*9000000)
    Password_reset.update_OTP(req.body.email,otp)
    send_opt_to_mail.sending_opt_to_mail(req.body.email,otp)
    console.log(otp)

    let jwtSecretKey = process.env.JWT_SECRET_KEY;

    let data = {
        email:req.body.email
    }

    const token = jwt.sign(data, jwtSecretKey);

    res.cookie("UserSession", token);

    res.redirect('/Reset_password/data')
  }
  else
  {
    res.send('User does not Exists')
  }



})

router.get('/Reset_password/data',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../html_templates')
    };

    var fileName = 'ResetPassword_otp.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})


router.post('/Reset_password/data',async(req,res)=>{
  if(await Password_reset.update_password(jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY).email,req.body.otp,req.body.password)==true)
  {
    res.send('otp Changed')
  }
  else
  {
    res.send('OTP invalid')
  }
})







module.exports=router;
