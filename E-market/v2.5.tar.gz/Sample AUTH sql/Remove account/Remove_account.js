const express = require('express');
const router=express.Router();
//const methods = require('./methods.js');
const jwt = require('jsonwebtoken');
const path = require('path');
const methods = require('./../scripts/password_reset.js')
const sendmail = require('./../scripts/sending_otp_mail.js')
const db = require('./../database/database.js')





router.get('/Remove_account',(req,res)=>{

  var otp=Math.floor(100000+Math.random()*9000000)
  console.log(otp)
  methods.update_OTP(jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY).email,otp)
  sendmail.sending_opt_to_mail(jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY).email,otp)
  var options = {
        root: path.join(__dirname,'./../html_templates')
    };

    var fileName = 'Remove_account.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})







router.post('/Remove_account',async function(req,res){

  db.run(`DELETE FROM UserDatabase WHERE email='${jwt.verify(req.cookies.UserSession,process.env.JWT_SECRET_KEY).email}' AND email_otp='${req.body.otp}'`)

  res.send('account Will be Deleted if OTP is right Else try again From the start')

})






module.exports=router;
