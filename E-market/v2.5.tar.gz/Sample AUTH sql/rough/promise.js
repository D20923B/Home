const express = require('express')
const multer = require('multer')
const app = express()

const fileStoreageEngine = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, './images');
    },
    filename: function (req, file, callback) {
        callback(null, file.originalname);
    }
});

const upload = multer({storage:fileStoreageEngine});

app.post("/single", upload.single('image'),(req,res)=>{
  console.log(req.file);

})


app.listen(5000)
