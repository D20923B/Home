const link_list = require('./link_list.js')
const item_database = new link_list.link_list()
const db=require("./../database/database.js");
const jwt = require('jsonwebtoken');


async function get_added_by(item_name)
{
  let res = await item_database.get_added_by(item_name)
  return res
}

async function get_address(username)
{
  let user_Exists=new Promise(function(myResolve,err)
  {
    db.all(`SELECT * FROM UserDatabase WHERE email='${username}' AND admin='TRUE'`,(err,row)=>{
        if(row.length==1)
        {
          myResolve(row)
        }
        else if (row.length==0)
        {
          myResolve(false)
        }
        })
  })

    let useraddress = await user_Exists
    return useraddress
}

function add(item_name,item_price,image_path,email)
{
  item_database.add(item_name,item_price,image_path,email)
}

function show()
{
  console.log(item_database)
}

function delete_items(item_name)
{
  item_database.remove(item_name)
}

async function check_empty()
{
  let res =await item_database.check_empty()
  return res
}

async function entire_item_history()
{
  let res = await item_database.entire_item_history()
  return res
}

async function next(item_name)
{
  let res = await item_database.next(item_name)
  return res
}

async function previous(item_name)
{
  let res = await item_database.previous(item_name)
  return res
}

exports.add=add
exports.show=show
exports.delete_items=delete_items
exports.check_empty=check_empty
exports.next=next
exports.previous=previous
exports.entire_item_history=entire_item_history
exports.get_added_by=get_added_by
exports.get_address=get_address
//different functions and class functions to work here
