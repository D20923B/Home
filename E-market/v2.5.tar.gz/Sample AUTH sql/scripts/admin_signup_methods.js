const db = require('./../database/database.js')
const sendmail = require('./../scripts/sending_otp_mail.js')

async function store_data(username,password,address,email,phone_number)
{

  var otp=Math.floor(100000+Math.random()*9000000)
  console.log(otp)
  sendmail.sending_opt_to_mail(email,otp)
  db.run(`INSERT INTO UserDatabase (username,password,address,email,Phone_number,email_otp,email_veryfied,admin) VALUES('${username}','${password}','${address}','${email}','${phone_number}','${otp}','FALSE','TRUE');`)

}








exports.store_data=store_data
