const db=require("./../database/database.js");
const md5= require('md5')

async function login_creds(email,password)
{
  password=md5(password)
  let check =await new Promise(function(result)
  {
      db.all(`SELECT * FROM UserDatabase WHERE email='${email}' AND password='${password}'`,(err,row)=>{

        if(row.length==1)
        {
          result(true)
        }
        else if(row.length==0)
        {
          result(false)
        }

      })
  })
  return check
}


async function email_activated(email)
{
  //preoblem here
  let check = await new Promise(function(result)
  {
    db.all(`SELECT * FROM UserDatabase WHERE email='${email}'`,(err,row)=>{

      if((row[0].email_veryfied)=='FALSE')
      {
        result(false)
      }
      else
      {
        result(true)
      }
    })
  })


  return check
}


exports.login_creds=login_creds
exports.email_activated=email_activated
