const md5 = require('md5js');


async function Password_Hash(password)
{

const hash = md5(password);

return hash
}

exports.Password_Hash = Password_Hash;
