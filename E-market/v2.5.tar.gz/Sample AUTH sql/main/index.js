const express = require('express');
const app=express();
const router = express.Router();
const bodyParser = require('body-parser');
const sign_up = require('./../sign_up/sign_up.js');
const sign_in = require('./../sign_in/sign_in.js');
const Reset_password=require('./../Reset_password/Reset_password.js')
const Remove_account=require('./../Remove account/Remove_account.js')
const Admin_signup=require('./../admin_signup/admin_signup.js')
const Add_item = require('./../Shopping cart mechanism/main.js')
const send_opt_to_mail = require('./../scripts/sending_otp_mail.js')
const owner_functions = require('./../owner_module/main.js')
const dotenv = require('dotenv');
const cookieParser=require('cookie-parser')
const path = require('path');
const crypto = require('crypto')
const fs = require('fs')

app.use(cookieParser())
app.use(bodyParser.urlencoded({ extended: false }));
app.use("/signup",sign_up);
app.use("/signin",sign_in);
app.use(Reset_password)
app.use(Remove_account)
app.use(Admin_signup)
app.use(Add_item)
app.use(owner_functions)
app.use(router);
dotenv.config();


//send_opt_to_mail.sending_opt_to_mail(process.env.email,process.env.Special_key)


router.get('/',(req,res)=>{

  var options = {
        root: path.join(__dirname,'./../html_templates')
    };

    var fileName = 'Home.html';
    res.sendFile(fileName, options, function (err) {
        if (err) {
            next(err);
        }
    });

})

app.listen(process.env.PORT)
